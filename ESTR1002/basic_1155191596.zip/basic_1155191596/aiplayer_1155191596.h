int aiplayer_1155191596(int player, const int* board);
int sub_dir_validity_1155191596(int player, const int* board, int location, int direction);
int check_loc_validity_1155191596(int player, const int* board, int location);
int object_cmp1_1155191596(int player, const int* board, int location) ;