package otherfiles;

import java.math.BigInteger;

public class HashTable_orig<T> {

    // constructor
    // T is the type of the value of the HT: should be ptr to the LL
    // input param values is all the predefined values in the hash table
    public HashTable_orig(T[] values) {
        // TODO: initialize the hash table.
        // You can define or choose type T based on your needs.
        // create table
    }

    public boolean delete(BigInteger key) {
        // TODO: delete an existing value.
        // Return true if successfully deleted, false if the key does not exist in the database.
        return false;
    }

    public void insert(T value) {
        // TODO: insert a new value into the database.
        // Do not need to return anything.
    }

    public T query(BigInteger key) {
        // TODO: query by key. Return null if the key does not exist.
        // Return the query result. Return null if the key does not exist in the database.
        return null;
    }
}
