package csci2100;

import java.math.BigInteger;
import java.util.Hashtable;

import javax.swing.plaf.basic.BasicGraphicsUtils;

import csci2100.MemMap.MemMapNode;

public class MemoryManager {

    public enum MemoryStrategy {
        FIRST_FIT,
        BEST_FIT,
        WORST_FIT;
    }

    private MemoryStrategy strategy;

    public static final BigInteger TOTAL_BYTES = new BigInteger("4294967296"); // 4GB = 4*1024*1024*1024 Bytes

    MemMap memMap;
    HashTable htOfFreeSize, htOfAddr;
    BigInteger maxBlockSize;

    // constructor
    public MemoryManager(MemoryStrategy strategy) {
        this.strategy = strategy;
        // TODO
        // Initialize the hash tables for memory storage.
        // int[] initValues = new int[99];
        // HashTable<int> ht = new HashTable<int>(initValues);
        // HashTable<Integer> ht = new HashTable<Integer>(initValues);
        // Do not need to return anything.

        // init memMap
        memMap = new MemMap(TOTAL_BYTES); // new memMap, first free node already init
        // memMap.insert(null, new MemMapNode(new BigInteger("0"), TOTAL_BYTES, false));
        // // initially, there is only 1 free node in the memMap

        // init htOfFreeSize: 1 free block and a max size
        htOfFreeSize = new HashTable();
        htOfFreeSize.put(TOTAL_BYTES, memMap.firstNode); // initially, only 1 free node
        maxBlockSize = TOTAL_BYTES; // maxBlockSize

        // init hTofAddr
        htOfAddr = new HashTable();
        htOfAddr.put(new BigInteger("0"), memMap.firstNode); // initially only 1 node

        // testing: print out the 3 structures
        Debug.dbgPrint("Init finished, current status:");
        print3Tables();
    }

    public int request(MemoryOperation op) {
        // TODO
        // Accepts a space request and allocate memory
        // If the memory is not available, the request should not be accepted
        // Allocate the memory according to the current strategy unless the address is
        // given
        // Return the allocated address if the memory is allocated successfully,
        // otherwise return -1

        MemMapNode toInsert;
        // Debug.printFileNameAndLineNumber();

        // request without size: find the valid memMapNode (or else return -1)
        // for this kind of search, the address returned must be the first address of a
        // memMap block
        if (op.getAddr() == null) {

            switch (strategy) {

                case FIRST_FIT:
                    // Debug.printFileNameAndLineNumber();
                    // loop through hash table by address to find the first available address
                    BigInteger currAddr = new BigInteger("0");
                    MemMapNode currMemMapNode = (MemMapNode) htOfAddr.get(currAddr);
                    while (true) { // loop through the table
                        if (currMemMapNode == null) {
                            return -1;
                        } // already finished looping, can't find any valid address

                        if (currMemMapNode.size.compareTo(op.getSize()) != -1 && !currMemMapNode.isOccupied) { // if size bigger or equals to the request size and not occupied: found the one
                            op.setAddr(currAddr);
                            toInsert = currMemMapNode;
                            break;
                        }

                        currAddr = currAddr.add(currMemMapNode.size);
                        currMemMapNode = (MemMapNode) htOfAddr.get(currAddr);
                    }

                    // Debug.dbgPrint("curr addr: " + currAddr);
                    break;

                case BEST_FIT:
                    // // search in the size hash table to get the the address with the best size
                    // (or return invalid)
                    // boolean notFoundFlagBF = true;
                    // for(BigInteger i = op.getSize(); i.compareTo(maxBlockSize) != 1/* i <= max*/;
                    // i = i.add(new BigInteger("1"))) { // getSize to maxSize
                    // MemMapNode nodeFound = (MemMapNode)htOfFreeSize.get(i);
                    // if(nodeFound != null) { // found the node

                    // op.setAddr(nodeFound.startingAddr);
                    // toInsert = nodeFound;
                    // notFoundFlagBF = false;
                    // break;
                    // }
                    // }

                    // if(notFoundFlagBF) {return -1;} // not found in the end
                    // break;

                    // linearly loop through the hash table to get the closest address

                    // find the kvp in htOfFreeSize: whose key(size) is successor of op.getSize()
                    // and has the least starting address
                    toInsert = htOfFreeSize.getSuccKeyMinAddr(op.getSize());
                    op.setAddr(toInsert.startingAddr);

                default: // Worst fit
                    // return the address of the max size: the backward search of BestFit
                    // boolean notFoundFlagWF = true;
                    // for(BigInteger i = maxBlockSize; i.compareTo(op.getSize()) != -1/* i >=
                    // intended size */; i = i.add(new BigInteger("-1"))) { // maxSize to getSize()
                    // MemMapNode nodeFound = (MemMapNode)htOfFreeSize.get(i);
                    // if(nodeFound != null) { // found the node
                    // op.setAddr(nodeFound.startingAddr);
                    // toInsert = nodeFound;
                    // notFoundFlagWF = false;
                    // break;
                    // }
                    // }

                    // if(notFoundFlagWF) {return -1;} // not found in the end

                    if (maxBlockSize.compareTo(op.getSize()) == 1) {
                        MemMapNode curr = (MemMapNode) htOfFreeSize.getMinAddr(maxBlockSize);
                        op.setAddr(curr.startingAddr);
                        toInsert = curr;
                    } else {
                        return -1;
                    }
                    break;
            }
        }

        // request with address: find the valid memMapNode or else return -1
        else {
            // first find the MemMapNode of the target address

            toInsert = htOfAddr.getPredKey(op.getAddr());
            if (toInsert == null) {
                Debug.dbgPrint("wrong. toInsert is null");
            }

            // check if it is valid, if not return -1
            /// if the MemMapNode is already occupied, invalid
            if (toInsert.isOccupied) {
                return -1;
            }

            /// if the end address of the request block > end address of toInsert, invalid
            BigInteger requestEnd = op.getAddr().add(op.getSize()).subtract(new BigInteger("1"));
            BigInteger toInsertEnd = toInsert.startingAddr.add(toInsert.size).subtract(new BigInteger("1"));
            if (requestEnd.compareTo(toInsertEnd) == 1) {
                return -1;
            }

            // otherwise it is valid, go and insert
        }

        // Debug.printFileNameAndLineNumber();
        // insert by updating 3 structures, and return the inserted address
        // Debug.dbgPrint("insert block's starting address: " + toInsert.startingAddr);

        /// mMNode2: the requested block
        //// update in memMap
        MemMapNode mMNode2 = new MemMapNode(op.getAddr(), op.getSize(), true);
        memMap.insert(toInsert, mMNode2);

        //// update in htOfAddr
        htOfAddr.put(mMNode2.startingAddr, mMNode2);

        //// update in htOfFreeSize
        // htOfFreeSize.put(mMNode2.size, mMNode2);    // wrong: mMNode2 is occupied
        // no need to update maxBlockSize, since it is a sub block of toInsert

        /// mMNode1: the part of block before requested block
        if (toInsert.startingAddr.compareTo(op.getAddr()) == -1) { // startingAddr < request address: there is mMNode1
            //// update in memMap
            // Debug.dbgPrint("op.getAddr(), toInsert.startingAddr" + op.getAddr() + " " +
            //// toInsert.startingAddr + "op.getAddr().subtract(toInsert.startingAddr)==" +
            //// op.getAddr().subtract(toInsert.startingAddr));
            MemMapNode mMNode1 = new MemMapNode(toInsert.startingAddr, op.getAddr().subtract(toInsert.startingAddr),
                    false); // update in memMap
            // MemMapNode mMNode1 = new MemMapNode(toInsert.startingAddr, new
            // BigInteger("-1"), false);
            // Debug.dbgPrint("before insert mMNode1, now mamMap is:");
            // memMap.printMemMap();

            memMap.insert(toInsert, mMNode1);

            // Debug.dbgPrint("done insert mMNode1, now mamMap is:");
            // memMap.printMemMap();

            //// update in htOfAddr
            htOfAddr.put(toInsert.startingAddr, mMNode1);

            //// update in htOfFreeSize
            htOfFreeSize.put(mMNode1.size, mMNode1);    // mMNode1 must be free
            // no need to update maxBlockSize, since it is a sub block of toInsert
        }

        /// mMNode3: the part of block after requested block
        BigInteger mMNode3Start = mMNode2.startingAddr.add(mMNode2.size); // mMNode2.start + mMNode2.size
        BigInteger toInsertEnd = toInsert.startingAddr.add(toInsert.size).subtract(new BigInteger("1"));// toInsert.start
                                                                                                        // +
                                                                                                        // toInsert.size
                                                                                                        // - 1
        if (mMNode3Start.compareTo(toInsertEnd) == -1) { // <: if mMNode3 exist
            //// update in memMap
            MemMapNode mMNode3 = new MemMapNode(mMNode3Start,
                    toInsertEnd.subtract(mMNode3Start).add(new BigInteger("1")), false); // update in memMap, size =
                                                                                         // toInsertEnd - mMNode3Start +
                                                                                         // 1
            memMap.insert(mMNode2, mMNode3);

            //// update in htOfAddr
            htOfAddr.put(mMNode3Start, mMNode3);

            //// update in htOfFreeSize
            htOfFreeSize.put(mMNode3.size, mMNode3);    // mMNode3 must be free
            // no need to update maxBlockSize, since it is a sub block of toInsert
        }

        /// delete toInsert
        //// update in memMap
        memMap.delete(toInsert);

        //// update in htOfAddr
        htOfAddr.remove(toInsert.startingAddr, toInsert);

        //// update in htOfFreeSize
        htOfFreeSize.remove(toInsert.size, toInsert);
        // Debug.printFileNameAndLineNumber();
        if (toInsert.size == maxBlockSize) {
            maxBlockSize = htOfFreeSize.getMaxBlockSize();
        }

        // testing
        Debug.dbgPrint("request done, the current structure:");
        print3Tables();

        // return address
        return op.getAddr().intValue();
    }

    public boolean release(MemoryOperation op) {
        // TODO
        // Accepts a space release and release memory
        // Return true if the memory is released successfully, otherwise return false

        // find the current block
        MemMapNode currMemMapNode = htOfAddr.getPredKey(op.getAddr());
        
        // if current block is free and all of target block is inside current block, return false
        BigInteger currMMNodeEnd = currMemMapNode.startingAddr.add(currMemMapNode.size).subtract(new BigInteger("1"));
        BigInteger tarEndAddr = op.getAddr().add(op.getSize()).subtract(new BigInteger("1"));
        if(!currMemMapNode.isOccupied && currMMNodeEnd.compareTo(tarEndAddr) == 1) {
            return false;
        }

        // check whole target block and get (N1stt, N1end) -> (N2stt, N2end) -> (N3stt, N3end)
        BigInteger N1stt, N1end, N2stt, N2end, N3stt, N3end;
        if(currMemMapNode.isOccupied) {     // if the start address is in the occupied block
            N1stt = currMemMapNode.startingAddr;
            N1end = op.getAddr().subtract(new BigInteger("1"));
            N2stt = op.getAddr();
        }
        else {  // if the start address is in free block
            N1stt = N1end = N2stt = currMemMapNode.startingAddr;
        }

        // loop through the blocks overlapping with target block and delete them
        MemMapNode prev = currMemMapNode.prevNode;      // for inserting N1, N2, N3
        while(currMMNodeEnd.compareTo(tarEndAddr) == -1) {  // currMMNend < tarEnd: not over yet
            // delete this MemMapNode
            memMap.delete(currMemMapNode);

            // update htOfAddr
            htOfAddr.remove(currMemMapNode.startingAddr, currMemMapNode);

            // update hTofSize and maxSize
            if(!currMemMapNode.isOccupied) {
                htOfFreeSize.remove(currMemMapNode.size, currMemMapNode);
                if(currMemMapNode.size.compareTo(maxBlockSize) == 0) {     
                    maxBlockSize = htOfFreeSize.getMaxBlockSize();
                }
            }
            
            // update
            currMemMapNode = currMemMapNode.nextNode;
            currMMNodeEnd = currMemMapNode.startingAddr.add(currMemMapNode.size).subtract(new BigInteger("1"));
        }
        // delete this MemMapNode
        memMap.delete(currMemMapNode);
        // update htOfAddr
        htOfAddr.remove(currMemMapNode.startingAddr, currMemMapNode);
        // update hTofSize and maxSize
        if(!currMemMapNode.isOccupied) {
            htOfFreeSize.remove(currMemMapNode.size, currMemMapNode);
            if(currMemMapNode.size.compareTo(maxBlockSize) == 0) {     
                maxBlockSize = htOfFreeSize.getMaxBlockSize();
            }
        }

        // get N2end, N3stt, N3end
        if(currMemMapNode.isOccupied) {
            N2end = tarEndAddr;
            N3stt = tarEndAddr.add(new BigInteger("1"));
            N3end = currMMNodeEnd;
        }
        else {      // the memMapNode is free, then no N3
            N2end = N3end = N3stt = currMMNodeEnd;
        }

        // Debug.dbgPrint("(N1stt, N1end) -> (N2stt, N2end) -> (N3stt, N3end): " + "(" + N1stt +","+ N1end+") -> ("+N2stt+","+ N2end+") -> ("+N3stt+","+ N3end+")");   // correct

        // insert N1, N2, N3 after prev (if prev is null than insert in the first node)
        /// insert N2
        MemMapNode n2 = new MemMapNode(N2stt, N2end.subtract(N2stt).add(new BigInteger("1")), false);
        memMap.insert(prev, n2);
        // Debug.dbgPrint("n2 inserted");
        // update 2 hT (n2 must be free)
        htOfAddr.put(n2.startingAddr, n2);
        htOfFreeSize.put(n2.size, n2);      // n1 must be alloc
        if(n2.size.compareTo(maxBlockSize) == 1) {
            maxBlockSize = n2.size;
        }
    

        /// if exist, insert N1
        if(N1stt.compareTo(N1end) == -1) {
            MemMapNode n1 = new MemMapNode(N1stt, N1end.subtract(N1stt).add(new BigInteger("1")), true);
            memMap.insert(prev, n1);
            // update 2 hT
            htOfAddr.put(n1.startingAddr, n1);
            // htOfFreeSize.put(n1.size, n1);      // n1 must be alloc
            // if(n1.size.compareTo(maxBlockSize) == 1) {
            //     maxBlockSize = n1.size;
            // }
        }

        /// if exist, insert N3
        if(N3stt.compareTo(N3end) == -1) {
            MemMapNode n3 = new MemMapNode(N3stt, N3end.subtract(N3stt).add(new BigInteger("1")), true);
            memMap.insert(n2, n3);
            // update 2 hT
            htOfAddr.put(n3.startingAddr, n3);
            // htOfFreeSize.put(n3.size, n3);    // n3 must be alloc
            // if(n3.size.compareTo(maxBlockSize) == 1) {
            //     maxBlockSize = n3.size;
            // }
        }

        print3Tables();

        return true;
    }

    /**
     * test only
     */
    void print3Tables() {
        if(!Debug.isDebugging) return;
        
        // print mem map
        System.out.println("memMap: (addr, size, occupation status)");
        memMap.printMemMap();
        System.out.println();

        System.out.print("\nhtOfAddr: (starting addr, memMapAddr)");
        htOfAddr.dump();

        System.out.print("\nhtOfFreeSize: (size, memMapAddr)");
        htOfFreeSize.dump();
        System.out.println("with max block size:" + maxBlockSize + "\n");
    }

    public static void main(String[] args) {
        // init
        MemoryManager memManager = new MemoryManager(MemoryStrategy.FIRST_FIT);
    }
}
