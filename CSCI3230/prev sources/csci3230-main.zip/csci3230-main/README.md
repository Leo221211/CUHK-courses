# csci3230
2023-2024 Sem 1 Fundamentals of Artificial Intelligence (CSCI3230)
